/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unicolombo.pb20232;

import java.util.Vector;

/**
 *
 * @author Luis Maldonado
 */

public class Equipos {
     
   
     
   public String nombre1 = "NEKOMA";
   public String sede1 = "SOCORRO";
  public String tipodejuego1 = "MASCULINO";
  public String entrenador = "RRORO";
  public String horarios = "TARDE";
    
}
